module.exports = { 
    testReturnUrl : "https://test-node-api.tnpowerfinance.com/tnpfc/v1/processPGResponse", 
    prodReturnUrl : "https://portal-api.tnpowerfinance.com/tnpfc/v1/processPGResponse",
    BeneficiaryBank :"HDFC",
    IFSCCode: "HDFC0000082",
    NameofBeneficiaryAccount:"TAMILNADU POWER FIN AND INF DEV COR LTD",
    PaymentReference:"New FD" 
}
       