// const RolesEnum = Object.freeze({"GM":"ROL01", "CMD":"ROL02"});
// const RolesEnum1 = Object.freeze({"GM":"ROL01", "CMD":"ROL02"});
module.exports = {
    RolesEnum : Object.freeze({
        GM: "ROL01", 
        CMD: "ROL02"
    }),
    DaysEnum : Object.freeze({
        Monday: 1, 
        Monday: 2, 
        Monday: 3, 
        Monday: 4, 
        Monday: 5, 
        Monday: 6, 
        Monday: 7 
    })
}
